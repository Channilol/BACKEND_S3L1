﻿using System.ComponentModel.Design;

namespace EsercizioS3L1CONSOLE
{
    internal class Program
    {
        static void Main(string[] args)
        {
            UserActions.Actions();
            Console.ReadLine();
        }

        public class MenuElement
        {
            public string Nome { get; set; }
            public double Prezzo { get; set;}
        }

        static object[] Menu = new object[] {
            new MenuElement { Nome = "Coca Cola 150ml", Prezzo = 2.50},
            new MenuElement { Nome = "Insalata di pollo", Prezzo = 5.20},
            new MenuElement { Nome = "Pizza Marghertita", Prezzo = 10.00},
            new MenuElement { Nome = "Pizza 4 formaggi", Prezzo = 12.50},
            new MenuElement{ Nome = "Pz patatine fritte", Prezzo = 3.50},
            new MenuElement { Nome = "Insalata di riso", Prezzo = 8.00},
            new MenuElement{ Nome = "Frutta di stagione", Prezzo = 5.00},
            new MenuElement { Nome = "Pizza fritta", Prezzo = 5.00},
            new MenuElement{ Nome = "Piadina vegetariana", Prezzo = 6.00},
            new MenuElement { Nome = "Panino Hamburger", Prezzo = 7.90},
        };

        public static class UserActions
        {
            public static List<int> Orders = new List<int>();
            public static double TotalOrder = 0;
            public static string isOrder;

            public static void Actions()
            {
                Console.Clear();
                Console.WriteLine("Buongiorno!\nCosa desidera fare? \n1. Guardare il menù e ordinare \n2. Uscire dall'applicazione\n");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    Console.Clear();
                    ShowMenu();
                    Console.WriteLine("Desideri ordinare qualcosa? Si/No\n");
                    isOrder = Console.ReadLine().ToLower();
                    if (isOrder == "si")
                    {
                        ReOrder();
                    }
                    else
                    {
                        Actions();
                    }
                }
                else if (input == "2")
                {
                    Console.WriteLine("\nPremi invio due volte per uscire dall'applicazione");
                }
                else
                {
                    Console.WriteLine("\nComando errato\n");
                    Actions();
                }
            }

            public static void ReOrder()
            {
                string reOrder;
                do
                {
                    Console.Clear();
                    ShowMenu();
                    AddMenuElement();

                    Console.WriteLine("\n============================================");
                    Console.WriteLine("Desideri riordinare qualcos'altro? Si/No\n");
                    reOrder = Console.ReadLine().ToLower();

                    if (reOrder == "no")
                    {
                        Console.Clear();
                        Console.WriteLine("==============SCONTRINO==============");
                        GetReceipt();
                        Console.WriteLine("==============SCONTRINO==============");
                        return;
                    }
                    else if (reOrder == "si")
                    {

                    }
                    else
                    {
                        Console.WriteLine("Comando errato");
                        ReOrder();
                    }
                } while (reOrder == "si");
            }

            public static void AddMenuElement()
            {
                Console.WriteLine("\nCosa desideri ordinare? Scrivi il numero del piatto\n");
                string input = Console.ReadLine();
                int numeroPiatto;
                bool isConverted = int.TryParse(input, out numeroPiatto);

                if (numeroPiatto == 1 || numeroPiatto == 2 || numeroPiatto == 3 || numeroPiatto == 4 || numeroPiatto == 5 || numeroPiatto == 6 || numeroPiatto == 7 || numeroPiatto == 8 || numeroPiatto == 9 || numeroPiatto == 10)
                {
                    numeroPiatto--;
                    Orders.Add(numeroPiatto);
                    TotalOrder += ((MenuElement)Menu[numeroPiatto]).Prezzo;
                    Console.WriteLine($"\nHai ordinato x1 {((MenuElement)Menu[numeroPiatto]).Nome}");
                }
                else
                {
                    Console.WriteLine("Questo piatto non esiste, scrivi un numero giusto");
                    AddMenuElement();
                }  
            }

            public static void GetReceipt()
            {
                foreach (int element in Orders)
                {
                    MenuElement menuElement = (MenuElement)Menu[element];
                    Console.WriteLine($"{menuElement.Nome} Prezzo: {menuElement.Prezzo} euro");
                };
                Console.WriteLine($"Totale da pagare: {Math.Round(TotalOrder, 2)} euro");
                Console.WriteLine("Grazie e arrivederci!");
            }

            public static void ShowMenu()
            {
                Console.WriteLine("================MENU================");
                for (int i = 0; i < Menu.Length; i++)
                {
                    int index = i + 1;
                    Console.WriteLine($"{index}. {((MenuElement)Menu[i]).Nome}, Prezzo: {((MenuElement)Menu[i]).Prezzo} euro");
                }
                Console.WriteLine("================MENU================\n");
            }
        }
    }
}